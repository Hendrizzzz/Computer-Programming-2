package inheritancedemo;

public class placeholder {
}
